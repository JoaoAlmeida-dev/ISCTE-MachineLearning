def mean(input_list: list):
    if len(input_list) == 0:
        return -1
    else:
        return sum(input_list) / len(input_list)



